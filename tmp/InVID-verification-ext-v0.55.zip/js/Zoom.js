function refreshTest(){

  $('#test').elevateZoom({
    scrollZoom : true,
    zoomType: "inner",
    cursor: "crosshair",
    zoomWindowFadeIn: 500,
    zoomWindowFadeOut: 750
  }); 
}

function refreshTest2(){

  $("#test2").elevateZoom({
   scrollZoom : true,
   zoomType : "lens",
   lensShape	 : "round",
   lensSize : 200
 });

}