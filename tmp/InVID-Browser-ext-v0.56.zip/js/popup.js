chrome.tabs.create({url:"invid.html"});
window.close();